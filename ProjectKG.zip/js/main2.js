(function (){ //works on page load
    blueLine();
    var recover = '';
    var recovernotes = [];
    var count = localStorage.getItem('count');
    for (let i=0; i<count;i++)
        recover = localStorage.getItem('recovernotes0');  
    
    recovernotes += recover;
    document.getElementById("noteinput").innerHTML = recovernotes;
})();

var taskd, date, time;
var pushpin,note,recover='', count = 0; flag=1; //flag checks if a note was removed
var noteArray = [];

function blueLine(){        //creates blue lines on the page
    for (var i=0; i<10; i++){
        var newDiv = document.createElement("div");
        newDiv.className = "blueline";
        document.getElementById("bluelines").appendChild(newDiv);
    } 
}

function sendTask(){
    readData();
    flag=1; //resets flag if a note was previously removed
    saveData();
    showData();
    clearFields();
    return false;
}

function readData(){
    taskd = document.getElementById("taskd").value;
    date = document.getElementById("date").value;
    time = document.getElementById("time").value;
}

class Note{
    constructor(taskd, date, time){
    this.taskd = taskd;
    this.date = date;
    this.time = time;
    }
}

function saveData(){
    var note1 = new Note(taskd,date,time);

    noteArray.push(note1);
    localStorage.setItem("noteArray", JSON.stringify(noteArray));
}
    
function showData(){
    let noteprint = '';
    let buttonStart = `<a id="rembutton" href="javascript:void(0);" class="disabled" onclick="removeNote(`;
    let buttonEnd = `); return false;" > <span class="glyphicon glyphicon-remove"></span> </a>`;
    let img2 = `<img class="img2" src="images/2.png">`;
    let noteAnimate = `<div id="note" class="note">`;
    let pushpinAnimate = `<img id="pushpin5" class="pushpin5" src="images/pushpin5.png">`;
    note = `<div id="note">`;
    pushpin = `<img id="pushpin5" src="images/pushpin5.png">`; 

    for (let i = 0; i < noteArray.length; i++){
        if (i == (noteArray.length-1) && flag==1){     //adds animation on the last note that is added
            note=noteAnimate;
            pushpin = pushpinAnimate;
        }

        let noteprepare = note + img2 + buttonStart + i + buttonEnd + '<div id="notetext">' + noteArray[i].taskd + '</div> <div id="notedate">' + noteArray[i].date + '</div> <div id="notetime">' + noteArray[i].time + '</div> <div id="fold"></div>' + pushpin + '</div>';
        noteprint+=noteprepare;
    
        var a = `localStorage.setItem("recovernotes` + i  + '",'+ `JSON.stringify(noteprint))`;
        JSON.parse(a);
        count++;   
    }
    localStorage.setItem("count",count);
    document.getElementById("noteinput").innerHTML = noteprint;
}

function clearFields(){
    document.getElementById("taskd").value = '';
    document.getElementById("date").value = '';
    document.getElementById("time").value = '';
}

function removeNote(i){
    noteArray.splice(i,1);
    saveDataAfterRemoval();
    flag=0;     //cancels animations when an item is removed
    showData();
}

function saveDataAfterRemoval(){
    localStorage.clear();
    localStorage.setItem("noteArray", JSON.stringify(noteArray));
}

/* 
$(document).ready(function(){
    $("#note").hover(function()
    {
        $(".glyphicon-remove").css("opacity", "1");
    }, function()
    {
        $(".glyphicon-remove").css("opacity", "0");
    });
});*/