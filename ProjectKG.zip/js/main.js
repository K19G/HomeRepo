window.onload = blueLine;

var taskd, date, time;
var taskdfocus, datefocus, timefocus;
var noteArray = [];

function blueLine(){
    for (var i=0; i<10; i++){
        var newDiv = document.createElement("div");
        newDiv.className = "blueline";
        document.getElementById("bluelines").appendChild(newDiv);
    } //creates blue lines on the page
}
function sendTask(){
    readData();
    saveData();
    showData();
    clearFields();
    return false;
}

function readData(){
    taskd = document.getElementById("taskd").value;
    date = document.getElementById("date").value;
    time = document.getElementById("time").value;
}

class Note{
    constructor(taskd, date, time){
    this.taskd = taskd;
    this.date = date;
    this.time = time;
    }
}

function saveData(){
    var note1 = new Note(taskd,date,time);

    noteArray.push(note1);
    localStorage.setItem("noteArray", JSON.stringify(noteArray));
}
    
function showData(){
    let noteprint='';
    let button = `<a id="rembutton" href="javascript:void(0);" class="disabled" onclick="removeNote(); return false;" > <span class="glyphicon glyphicon-remove"></span> </a>`;

    for (let i = 0; i < noteArray.length; i++){
        let noteprepare = '<div id="note" class="note">' + button + '<div id="notetext">' + noteArray[i].taskd + '</div> <div id="notedate">' + noteArray[i].date + '</div> <div id="notetime">' + noteArray[i].time + '</div> <div id="fold"></div> </div> ';
        noteprint+=noteprepare;
    }
    document.getElementById("noteinput").innerHTML = noteprint;
}

function clearFields(){
    document.getElementById("taskd").value = '';
    document.getElementById("date").value = '';
    document.getElementById("time").value = '';
}

function removeNote(){
    document.getElementById('rembutton').removeAttribute("onclick");
}

/*
    let img1 = `<img class="img1" src="images/1.png">`;
    let img2 = `<img class="img2" src="images/2.png">`;
    let img3 = `<img class="img3" src="images/3.png">`;
    let imgdiv = '<div id="imgdiv">' + img1 + img2 + img3 + '</div>';*/