buildHeader();
buildMainArticle();
buildSubArticle();
changeArrow();

var mainArticle = buildMainArticle("18.7.21 | ט' באב התשפ''א",
"<img src=images/1.jpg>",
 "בנט הבטיח חופש פולחן ליהודים בהר הבית, רע''מ: ''אל-אקצה - רק למוסלמים''",
  "רה''מ הודה למפכ''ל ולשר לביטחון הפנים על שפעלו ''באחריות ובשיקול דעת'' ושמרו על חופש הפולחן של 1,600 היהודים שעלו להר. הוא הדגיש כי חופש הפולחן יישמר גם בחגים המוסלמים. ח''כים ממפלגתו ימינה הגיעו להר והכעיסו את רע''מ: ''כניסת יהודים להר עלולה להוביל למלחמת דת הרסנית''",
  "איתמר אייכנר")

document.getElementById("date").innerHTML = mainArticle.date;
document.getElementById("mainhead").innerHTML = mainArticle.maintext;
document.getElementById("maintxt").innerHTML = mainArticle.subtext;
document.getElementById("writer").innerHTML = mainArticle.writer;
document.getElementById("mainimg").innerHTML = mainArticle.image;



var subArticle1 = buildSubArticle("אלה 20 חברות התעופה הטובות בעולם"
,"אתר דירוג חברות התעופה הנחשב Airlineratings גם הכתיר את 10 חברות הלואו-קוסט הטובות בעולם והמחלקה הראשונה הנוצצת מכולן"
,"אסף רוזן"
,"<img src=images/2.jpg>")

var subArticle2 = buildSubArticle("הדרך המרגשת של יאניס לאליפות ה-NBA",
"סיפור הסינדרלה האולטימטיבי: בן המהגרים שמכר שעונים מזויפים, הפך לאלוף ה-NBA ולאחד הכדורסלנים הגדולים בעולם. והכל התחיל במקרה",
"ynet ספורט",
"<img src=images/3.jpg>")

document.getElementById("sub1head").innerHTML = subArticle1.subhead;
document.getElementById("sub1txt").innerHTML = subArticle1.subtext;
document.getElementById("sub1writer").innerHTML = subArticle1.writer;
document.getElementById("sub1img").innerHTML = subArticle1.image;

document.getElementById("sub2head").innerHTML = subArticle2.subhead;
document.getElementById("sub2txt").innerHTML = subArticle2.subtext;
document.getElementById("sub2writer").innerHTML = subArticle2.writer;
document.getElementById("sub2img").innerHTML = subArticle2.image;

function changeArrow(){
    $("button").on("click", function() {
        var change = $(this);
        if (change.text() == change.data("text-swap")) {
            change.text(change.data("text-original"));
        } 
        else {
            change.data("text-original", change.text());
            change.text(change.data("text-swap"));
        }
    });
}

function buildHeader(){
    var img = document.createElement("img"); 
    img.src = "images/ynet.png"; 
    var src = document.getElementById("header");
    src.appendChild(img); 
}
function buildMainArticle(date, image, maintext, subtext, writer){
    var mainArt = {};
    mainArt.date = date;
    mainArt.image = image;
    mainArt.maintext = maintext;
    mainArt.subtext = subtext;
    mainArt.writer = writer;
    return mainArt;
}
function buildSubArticle(subhead, subtext, writer, image){
    var subArt = {};
    subArt.subhead = subhead;
    subArt.subtext = subtext;
    subArt.writer = writer;
    subArt.image = image;
    return subArt;
}

$(document).ready(function () {
    $("#header").hide();
    $("#header").delay(1000).fadeIn(100);  

    $("#navbar").hide();
    $("#navbar").delay(1500).fadeIn(100);  

    $("#wheel").hide();
    $("#wheel").delay(2000).fadeIn(100);  

    $("#main").hide();
    $("#main").delay(3000).fadeIn(100);  

    $("#sub").hide();
    $("#sub").delay(3000).fadeIn(100);  
}); 