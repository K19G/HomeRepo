$("ul li").click(function(){
    $(this).fadeOut("slow", function(){
        window.location.href = 'https://www.google.com/';
      });
  });

$("#red").mouseover(function(){
    $(this).animate({left:'350px'});
});
$("#red").mouseout(function(){
    $(this).animate({left:'0px'});
});

$("#blue").mouseover(function(){
    $(this).animate({opacity:0});
});
$("#blue").mouseout(function(){
    $(this).animate({opacity:1});
});

$("#green").mouseover(function(){
    $(this).animate({left:'350px'});
    $(this).animate({top:'650px'});
});
$("#green").mouseout(function(){
    $(this).animate({top:'422px'});
    $(this).animate({left:'8px'});
});

$("#black").mouseover(function(){
    $(this).animate({left:'350px'});
    $("p").animate({opacity: 1});
});
$("#black").click(function(){
    $(this).animate({top:'737px'});
    $(this).animate({left:'8px'});
    $("p").animate({opacity: 0});
});
/*
$("#pink").mouseover(function(){
    $(this).animate({height: '+=150px'});
    $(this).animate({width: '+=150px'});
});*/

$('#pink').click(function(){
    $(this).animate({height: '+=150px', width: '+=150px'});
});
$('#pink').click(function(){
    $(this).delay(2000).animate({height: '100px', width: '100px'});
});